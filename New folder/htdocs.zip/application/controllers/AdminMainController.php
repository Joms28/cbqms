<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminMainController extends CI_Controller {

  public function index(){
    $this->load->view ('admin/index');
  }

  public function create_admin(){

  }

  public function login(){

  }

  public function main(){

  }

  public function logout(){

  }

}
